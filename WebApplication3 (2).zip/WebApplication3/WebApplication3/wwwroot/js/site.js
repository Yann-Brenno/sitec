﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
const productContainer = document.querySelectorAll(".productContainer");
const prevBtn = document.querySelectorAll(".prevBtn");
const nextBtn = document.querySelectorAll(".nextBtn");

productContainer.forEach((card, i) => {
    let containerDimensions = card.getBoundingClientRect();
    let containerWidth = containerDimensions.width;

    nextBtn[i].addEventListener("click", () => {
        card.scrollLeft += containerWidth;
    })

    prevBtn[i].addEventListener("click", () => {
        card.scrollLeft -= containerWidth;
    })
});



// Dark/light mode

const toggleBtn = document.querySelector('#toggle-theme');
const body = document.body;

toggleBtn.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
});


//animação do botão de pesquisa
const search = document.querySelector('.search')
const btn = document.querySelector('.btn')
const input = document.querySelector('.input')
btn.addEventListener('click', () => {
    search.classList.toggle('active')
    input.focus()
})


//função que faz as buscas no botão de busca

function filtrar() {
    var input = document.querySelector(".input");
    var filtro = input.value.toUpperCase();
    var cards = document.querySelectorAll(".productCard");

    for (var i = 0; i < cards.length; i++) {
        var marca = cards[i].querySelector(".productBrand").textContent.toUpperCase();

        if (marca.indexOf(filtro) > -1) {
            cards[i].style.display = "";
        } else {
            cards[i].style.display = "none";
        }
    }
}

// Define a data limite de duração
const deadline = new Date("08 june 2023, 11:42:57").getTime();

// Atualiza o contador a cada segundo
const x = setInterval(function () {

    // Obtém a data e hora atual
    const now = new Date().getTime();

    // Calcula a diferença entre a data limite e a data atual
    const distance = deadline - now;

    // Calcula o tempo restante em dias, horas, minutos e segundos
    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    // Exibe o tempo restante no contador
    document.getElementById("countdown").innerHTML = `${days} dias, ${hours} horas, ${minutes} minutos, ${seconds} segundos`;

    // Quando o tempo acabar, exibe uma mensagem de encerramento
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("countdown").innerHTML = "Chave ASC expirada contate o administrador";

        document.getElementById("butao_copiar").style.display = "none";
        document.getElementById("nome_chave").style.display = "none";


    }
}, 1000);

// Função para copiar a chave de acesso
function copyKey() {
    const keyInput = document.getElementById("key");
    keyInput.select();
    keyInput.setSelectionRange(0, 99999);
    document.execCommand("copy");
}